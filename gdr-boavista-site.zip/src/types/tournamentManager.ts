export type TournamentManagerStatus =
  | 'draft'
  | 'setup'
  | 'calendar_generated'
  | 'published'
  | 'in_progress'
  | 'finished'
  | 'archived';

export type TournamentManagerTournament = {
  id: string;
  name: string;
  slug: string;
  edition: string | null;
  age_group: string | null;
  birth_year: string | null;
  football_type: string | null;
  gender: string | null;
  location: string | null;
  address: string | null;
  description: string | null;
  contact_phone: string | null;
  contact_email: string | null;
  status: TournamentManagerStatus;
  is_public: boolean;
  created_at: string;
  updated_at: string;
};
